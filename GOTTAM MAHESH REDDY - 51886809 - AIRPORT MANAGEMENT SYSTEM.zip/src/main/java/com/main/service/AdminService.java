package com.main.service;

import com.main.model.Admin;
import com.main.model.AdminLogin;

/**
 * @author gottammahesh.reddy This is an Admin Service Interface.
 */
public interface AdminService {

	public void saveAdmin(Admin admin);

	public Admin fetchAdminById(Integer adminId);

	public String fetchAdmin(AdminLogin adminLogin);

}
