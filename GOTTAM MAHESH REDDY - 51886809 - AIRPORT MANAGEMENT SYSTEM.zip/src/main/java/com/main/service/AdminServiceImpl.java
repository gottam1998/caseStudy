package com.main.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.AdminDao;
import com.main.model.Admin;
import com.main.model.AdminLogin;

/**
 * @author gottammahesh.reddy This is an Admin Service Impl.
 */
@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	private static Logger log = Logger.getLogger(AdminServiceImpl.class);
	@Autowired
	private AdminDao adminDao;

	@Override
	public void saveAdmin(Admin admin) {
		log.info("Inside service saveAdmin()");
		adminDao.saveAdmin(admin);

	}

	@Override
	public Admin fetchAdminById(Integer adminId) {
		Admin admin = adminDao.fetchAdminById(adminId);
		return admin;
	}

	@Override
	public String fetchAdmin(AdminLogin adminLogin) {
		String authentication = adminDao.fetchAdmin(adminLogin);
		return authentication;
	}

}
