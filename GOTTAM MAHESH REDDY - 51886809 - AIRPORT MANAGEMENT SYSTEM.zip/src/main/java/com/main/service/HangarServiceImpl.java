package com.main.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.HangarDao;
import com.main.model.Hangar;
import com.main.model.Pilot;
import com.main.model.Plane;

/**
 * @author gottammahesh.reddy This is an hangar Service Impl.
 */
@Service
@Transactional
public class HangarServiceImpl implements HangarService {

	private static Logger log = Logger.getLogger(HangarServiceImpl.class);
	@Autowired
	private HangarDao hangarDao;

	@Override
	public void saveHangar(Hangar hangar) {
		log.info("Inside service saveHangar()");
		hangarDao.saveHangar(hangar);

	}

	@Override
	public List<Hangar> fetchHangar() {
		log.info("Inside service fetchHangar()");
		List<Hangar> hangarList = hangarDao.fetchHangar();
		return hangarList;
	}

	@Override
	public Hangar fetchHangarById(Integer hangarId) {
		log.info("Inside service fetchHangarById()");
		Hangar hangar = hangarDao.fetchHangarById(hangarId);
		return hangar;
	}

	@Override
	public void updateHangar(Hangar hangar) {
		log.info("Inside service updateHangar()");
		hangarDao.updateHangar(hangar);

	}

	@Override
	public void deleteHangar(Integer hangerId) {
		log.info("Inside service deletehangar()");
		hangarDao.deleteHangar(hangerId);

	}

	@Override
	public List<Hangar> fetchPlaneHangar() {
		List<Hangar> planeHangarList = hangarDao.fetchPlaneHangar();
		return planeHangarList;
	}

	@Override
	public Hangar fetchByPlaneHangarId(Integer hangarId) {
		log.info("Inside service fetchByPlaneId()");
		Hangar hangar = hangarDao.fetchByPlaneHangarId(hangarId);
		return hangar;
	}

	@Override
	public void updatePlaneHangar(Hangar hangar) {
		log.info("Inside service updatePlane()");
		hangarDao.updatePlaneHangar(hangar);

	}

	@Override
	public List<Plane> fetchPlane() {
		log.info("Inside service fetchPilot()");
		List<Plane> planeList = hangarDao.fetchPlane();
		return planeList;
	}

}
