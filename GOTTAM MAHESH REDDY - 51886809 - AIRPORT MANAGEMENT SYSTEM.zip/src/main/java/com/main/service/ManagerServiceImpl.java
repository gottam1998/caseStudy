package com.main.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.ManagerDao;
import com.main.model.Login;
import com.main.model.Manager;

/**
 * @author gottammahesh.reddy This is an Manager Service Impl.
 */
@Service
@Transactional
public class ManagerServiceImpl implements ManagerService {

	private static Logger log = Logger.getLogger(ManagerServiceImpl.class);
	@Autowired
	private ManagerDao managerDao;

	@Override
	public void saveManager(Manager manager) {
		log.info("Inside service saveManager()");
		managerDao.saveManager(manager);

	}

	@Override
	public String fetchManager(Login login) {
		String authentication = managerDao.fetchManager(login);
		return authentication;
	}

}
