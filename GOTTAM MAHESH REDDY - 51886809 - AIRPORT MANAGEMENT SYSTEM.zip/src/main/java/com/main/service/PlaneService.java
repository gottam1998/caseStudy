package com.main.service;

import java.util.List;

import com.main.model.Pilot;
import com.main.model.Plane;

/**
 * @author gottammahesh.reddy This is an Plane Service Interface.
 */
public interface PlaneService {

	public void savePlane(Plane plane);

	public List<Plane> fetchPlane();

	public Plane fetchByPlaneId(Integer planeId);

	public void updatePlane(Plane plane);

	public void deletePlane(Integer planeId);

	public List<Plane> fetchPlanePilot();

	public Plane fetchByPlanePilotId(Integer planeId);

	public void updatePlanePilot(Plane plane);

	public List<Plane> fetchPlaneHangar();

	public Plane fetchByPlaneHangarId(Integer planeId);

	public void updatePlaneHangar(Plane plane);

	public List<Pilot> fetchPilot();

}
