package com.main.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.PilotDao;
import com.main.model.Pilot;

/**
 * @author gottammahesh.reddy This is an Pilot Service Impl.
 */
@Service
@Transactional
public class PilotServiceImpl implements PilotService {

	private static Logger log = Logger.getLogger(PilotServiceImpl.class);
	@Autowired
	private PilotDao pilotDao;

	@Override
	public void savePilot(Pilot pilot) {
		log.info("Inside service savePilot()");
		pilotDao.savePilot(pilot);

	}

	@Override
	public List<Pilot> fetchPilot() {
		log.info("Inside service fetchPilot()");
		List<Pilot> pilotList = pilotDao.fetchPilot();
		return pilotList;
	}

	@Override
	public Pilot fetchByPilotId(Integer pilotId) {
		log.info("Inside service fetchByPilotId()");
		Pilot pilot = pilotDao.fetchByPilotId(pilotId);
		return pilot;
	}

	@Override
	public void updatePilot(Pilot pilot) {
		log.info("Inside service updatePilot()");
		pilotDao.updatePilot(pilot);

	}

	@Override
	public void deletePilot(Integer pilotId) {
		log.info("Inside service deletePilot()");
		pilotDao.deletePilot(pilotId);

	}

}
