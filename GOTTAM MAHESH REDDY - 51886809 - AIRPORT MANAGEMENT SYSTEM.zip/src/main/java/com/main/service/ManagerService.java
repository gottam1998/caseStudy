package com.main.service;

import com.main.model.Login;
import com.main.model.Manager;

/**
 * @author gottammahesh.reddy This is an Manager Service Interface.
 */
public interface ManagerService {

	public void saveManager(Manager manager);

	public String fetchManager(Login login);

}
