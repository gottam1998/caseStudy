package com.main.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.PlaneDao;
import com.main.model.Pilot;
import com.main.model.Plane;

/**
 * @author gottammahesh.reddy This is an Plane Service Impl.
 */
@Service
@Transactional
public class PlaneServiceImpl implements PlaneService {

	private static Logger log = Logger.getLogger(PlaneServiceImpl.class);
	@Autowired
	private PlaneDao planeDao;

	@Override
	public void savePlane(Plane plane) {
		log.info("Inside service savePlane()");
		planeDao.savePlane(plane);

	}

	@Override
	public List<Plane> fetchPlane() {
		log.info("Inside service fetchPlane()");
		List<Plane> planeList = planeDao.fetchPlane();
		return planeList;
	}

	@Override
	public Plane fetchByPlaneId(Integer planeId) {
		log.info("Inside service fetchByPlaneId()");
		Plane plane = planeDao.fetchByPlaneId(planeId);
		return plane;
	}

	@Override
	public void updatePlane(Plane plane) {
		log.info("Inside service updatePlane()");
		planeDao.updatePlane(plane);

	}

	@Override
	public void deletePlane(Integer planeId) {
		log.info("Inside service deletePlane()");
		planeDao.deletePlane(planeId);

	}

	@Override
	public List<Plane> fetchPlanePilot() {
		List<Plane> planePilotList = planeDao.fetchPlanePilot();
		return planePilotList;
	}

	@Override
	public Plane fetchByPlanePilotId(Integer planeId) {
		log.info("Inside service fetchByPlaneId()");
		Plane plane = planeDao.fetchByPlanePilotId(planeId);
		return plane;
	}

	@Override
	public void updatePlanePilot(Plane plane) {
		log.info("Inside service updatePlane()");
		planeDao.updatePlanePilot(plane);

	}

	@Override
	public List<Plane> fetchPlaneHangar() {
		List<Plane> planeHangarList = planeDao.fetchPlaneHangar();
		return planeHangarList;
	}

	@Override
	public Plane fetchByPlaneHangarId(Integer planeId) {
		log.info("Inside service fetchByPlaneId()");
		Plane plane = planeDao.fetchByPlaneHangarId(planeId);
		return plane;
	}

	@Override
	public void updatePlaneHangar(Plane plane) {
		log.info("Inside service updatePlane()");
		planeDao.updatePlaneHangar(plane);

	}

	@Override
	public List<Pilot> fetchPilot() {
		log.info("Inside service fetchPilot()");
		List<Pilot> pilotList = planeDao.fetchPilot();
		return pilotList;
	}

}
