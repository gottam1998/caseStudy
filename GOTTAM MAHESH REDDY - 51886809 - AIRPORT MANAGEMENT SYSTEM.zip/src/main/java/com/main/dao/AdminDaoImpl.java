package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Admin;
import com.main.model.AdminLogin;

/**
 * @author gottammahesh.reddy This is an Admin Dao Impl which helps to fetch or
 *         insert the data in database.
 */
@Repository
public class AdminDaoImpl implements AdminDao {

	private static Logger log = Logger.getLogger(AdminDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveAdmin(Admin admin) {
		log.info("Inside dao saveAdmin()");
		sessionFactory.getCurrentSession().save(admin);
	}

	@Override
	public Admin fetchAdminById(Integer adminId) {
		Admin admin = (Admin) sessionFactory.getCurrentSession().get(Admin.class, adminId);
		return admin;
	}

	@Override
	public String fetchAdmin(AdminLogin adminLogin) {
		String authentication = "";
		Integer adminId = adminLogin.getAdminId();
		String adminPassword = adminLogin.getPassword();
		Query query = sessionFactory.getCurrentSession()
				.createQuery("select a from Admin a where a.id=:adminId and a.password=:adminPassword");
		query.setParameter("adminId", adminId);
		query.setParameter("adminPassword", adminPassword);
		List l = query.list();

		if (l != null && l.size() > 0) {
			authentication = "valid";

		} else {
			authentication = "invalid";
		}

		return authentication;
	}

}
