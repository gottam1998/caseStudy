package com.main.dao;

import com.main.model.Admin;
import com.main.model.AdminLogin;

/**
 * @author gottammahesh.reddy This is an Admin Dao Interface
 */
public interface AdminDao {

	public void saveAdmin(Admin admin);

	public Admin fetchAdminById(Integer adminId);

	public String fetchAdmin(AdminLogin adminLogin);

}
