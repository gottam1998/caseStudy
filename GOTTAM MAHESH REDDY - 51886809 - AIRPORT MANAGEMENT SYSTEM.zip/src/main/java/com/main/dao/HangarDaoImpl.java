package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Hangar;
import com.main.model.Pilot;
import com.main.model.Plane;

/**
 * @author gottammahesh.reddy This is an Hangar Dao Impl which helps to fetch or
 *         insert the data in database.
 */
@Repository
public class HangarDaoImpl implements HangarDao {

	private static Logger log = Logger.getLogger(HangarDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveHangar(Hangar hangar) {
		log.info("Inside dao saveHangar()");

		sessionFactory.getCurrentSession().save(hangar);

	}

	@Override
	public List<Hangar> fetchHangar() {
		log.info("Inside dao fetchHangar()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Hangar h");
		List<Hangar> hangarList = query.list();
		return hangarList;
	}

	@Override
	public Hangar fetchHangarById(Integer hangarId) {
		log.info("Inside dao fetchHangarById()");
		Hangar hangar = (Hangar) sessionFactory.getCurrentSession().get(Hangar.class, hangarId);
		return hangar;
	}

	@Override
	public void updateHangar(Hangar hangar) {
		log.info("Inside dao updateHangar()");
		sessionFactory.getCurrentSession().update(hangar);

	}

	@Override
	public void deleteHangar(Integer hangerId) {
		log.info("Inside dao deletehangar()");
		Query query = sessionFactory.getCurrentSession().createQuery("delete from Hangar h where h.id=:hangerId");
		query.setParameter("hangerId", hangerId);
		query.executeUpdate();

	}

	@Override
	public List<Hangar> fetchPlaneHangar() {
		log.info("Inside dao fetchPlane()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Hangar p");
		List<Hangar> planeHangarList = query.list();
		return planeHangarList;
	}

	@Override
	public Hangar fetchByPlaneHangarId(Integer hangarId) {
		log.info("Inside dao fetchByPlaneHangarId()");
		Hangar hangar = (Hangar) sessionFactory.getCurrentSession().get(Hangar.class, hangarId);
		return hangar;
	}

	@Override
	public void updatePlaneHangar(Hangar hangar) {
		log.info("Inside dao updatePlaneHangar()");
		sessionFactory.getCurrentSession().update(hangar);

	}

	@Override
	public List<Plane> fetchPlane() {
		log.info("Inside dao fetchPilot()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Plane p");
		List<Plane> planeList = query.list();
		return planeList;
	}

}
