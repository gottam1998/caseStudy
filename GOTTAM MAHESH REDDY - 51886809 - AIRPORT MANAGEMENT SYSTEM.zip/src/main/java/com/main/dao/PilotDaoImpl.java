package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Pilot;

/**
 * @author gottammahesh.reddy This is an Pilot Dao Impl which helps to fetch or
 *         insert the data in database.
 */
@Repository
public class PilotDaoImpl implements PilotDao {

	private static Logger log = Logger.getLogger(PilotDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void savePilot(Pilot pilot) {
		log.info("Inside dao savePilot()");
		sessionFactory.getCurrentSession().save(pilot);

	}

	@Override
	public List<Pilot> fetchPilot() {
		log.info("Inside dao fetchPilot()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Pilot p");
		List<Pilot> pilotList = query.list();
		return pilotList;
	}

	@Override
	public Pilot fetchByPilotId(Integer pilotId) {
		log.info("Inside dao fetchByPilotId()");
		Pilot pilot = (Pilot) sessionFactory.getCurrentSession().get(Pilot.class, pilotId);
		return pilot;
	}

	@Override
	public void updatePilot(Pilot pilot) {
		log.info("Inside dao updatePilot()");
		sessionFactory.getCurrentSession().update(pilot);

	}

	@Override
	public void deletePilot(Integer pilotId) {
		log.info("Inside dao deletePilot()");
		Query query = sessionFactory.getCurrentSession().createQuery("delete from Pilot p where p.id=:pilotId");
		query.setParameter("pilotId", pilotId);
		query.executeUpdate();

	}

}
