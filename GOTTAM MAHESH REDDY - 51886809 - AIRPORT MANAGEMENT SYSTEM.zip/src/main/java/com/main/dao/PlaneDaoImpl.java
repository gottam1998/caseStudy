package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Pilot;
import com.main.model.Plane;

/**
 * @author gottammahesh.reddy This is an Plane Dao Impl which helps to fetch or
 *         insert the data in database.
 */
@Repository
public class PlaneDaoImpl implements PlaneDao {

	private static Logger log = Logger.getLogger(PlaneDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void savePlane(Plane plane) {
		log.info("Inside dao savePlane()");
		sessionFactory.getCurrentSession().save(plane);

	}

	@Override
	public List<Plane> fetchPlane() {
		log.info("Inside dao fetchPlane()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Plane p");
		List<Plane> planeList = query.list();
		return planeList;
	}

	@Override
	public Plane fetchByPlaneId(Integer planeId) {
		log.info("Inside dao fetchByPlaneId()");
		Plane plane = (Plane) sessionFactory.getCurrentSession().get(Plane.class, planeId);
		return plane;
	}

	@Override
	public void updatePlane(Plane plane) {
		log.info("Inside dao updatePlane()");
		sessionFactory.getCurrentSession().update(plane);

	}

	@Override
	public void deletePlane(Integer planeId) {
		log.info("Inside dao deletePlane()");
		Query query = sessionFactory.getCurrentSession().createQuery("delete from Plane p where p.id=:planeId");
		query.setParameter("planeId", planeId);
		query.executeUpdate();

	}

	@Override
	public List<Plane> fetchPlanePilot() {
		log.info("Inside dao fetchPlane()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Plane p");
		List<Plane> planePilotList = query.list();
		return planePilotList;
	}

	@Override
	public Plane fetchByPlanePilotId(Integer planeId) {
		log.info("Inside dao fetchByPlaneId()");
		Plane plane = (Plane) sessionFactory.getCurrentSession().get(Plane.class, planeId);
		return plane;
	}

	@Override
	public void updatePlanePilot(Plane plane) {
		log.info("Inside dao updatePlane()");
		sessionFactory.getCurrentSession().update(plane);

	}

	@Override
	public List<Plane> fetchPlaneHangar() {
		log.info("Inside dao fetchPlane()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Plane p");
		List<Plane> planeHangarList = query.list();
		return planeHangarList;
	}

	@Override
	public Plane fetchByPlaneHangarId(Integer planeId) {
		log.info("Inside dao fetchByPlaneHangarId()");
		Plane plane = (Plane) sessionFactory.getCurrentSession().get(Plane.class, planeId);
		return plane;
	}

	@Override
	public void updatePlaneHangar(Plane plane) {
		log.info("Inside dao updatePlaneHangar()");
		sessionFactory.getCurrentSession().update(plane);

	}

	@Override
	public List<Pilot> fetchPilot() {
		log.info("Inside dao fetchPilot()");
		Query query = sessionFactory.getCurrentSession().createQuery("from Pilot p");
		List<Pilot> pilotList = query.list();
		return pilotList;
	}

}
