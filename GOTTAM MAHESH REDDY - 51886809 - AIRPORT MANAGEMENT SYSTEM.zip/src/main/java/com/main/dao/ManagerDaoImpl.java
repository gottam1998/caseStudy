package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Login;
import com.main.model.Manager;

/**
 * @author gottammahesh.reddy
 *This is an Manager Dao Impl which helps to fetch or insert the data in database. 
 */
@Repository
public class ManagerDaoImpl implements ManagerDao {

	private static Logger log = Logger.getLogger(ManagerDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveManager(Manager manager) {
		log.info("Inside dao saveStudent()");
		sessionFactory.getCurrentSession().save(manager);
		
	}

	@Override
	public String fetchManager(Login login) {
		String authentication="";
        Integer managerId=login.getManagerId();
        String password=login.getPassword();
        Query query=sessionFactory.getCurrentSession().
                createQuery("select m from Manager m where m.id=:managerId and m.password=:password");
        query.setParameter("managerId", managerId);
        query.setParameter("password", password);
        List l=query.list();
       
        if(l!=null && l.size()>0) {
            authentication="valid";
           
        }
        else {
            authentication="invalid";
        }
		return authentication;
	}

}
