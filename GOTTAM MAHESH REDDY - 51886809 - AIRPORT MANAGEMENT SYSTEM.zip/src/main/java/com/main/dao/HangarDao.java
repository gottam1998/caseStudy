package com.main.dao;

import java.util.List;

import com.main.model.Hangar;
import com.main.model.Plane;

/**
 * @author gottammahesh.reddy This is an Hangar Dao Interface
 */
public interface HangarDao {

	public void saveHangar(Hangar hangar);

	public List<Hangar> fetchHangar();

	public Hangar fetchHangarById(Integer hangarId);

	public void updateHangar(Hangar hangar);

	public void deleteHangar(Integer hangerId);

	public List<Hangar> fetchPlaneHangar();

	public Hangar fetchByPlaneHangarId(Integer hangarId);

	public void updatePlaneHangar(Hangar hangar);

	public List<Plane> fetchPlane();

}
