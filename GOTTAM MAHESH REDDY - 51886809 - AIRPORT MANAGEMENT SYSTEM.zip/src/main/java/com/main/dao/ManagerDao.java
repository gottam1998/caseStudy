package com.main.dao;

import com.main.model.Login;
import com.main.model.Manager;

/**
 * @author gottammahesh.reddy This is an Manager Dao Interface.
 */
public interface ManagerDao {

	public void saveManager(Manager manager);

	public String fetchManager(Login login);

}
