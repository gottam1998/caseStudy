package com.main.dao;

import java.util.List;

import com.main.model.Pilot;

/**
 * @author gottammahesh.reddy This is an Pilot Dao Interface.
 */
public interface PilotDao {

	public void savePilot(Pilot pilot);

	public List<Pilot> fetchPilot();

	public Pilot fetchByPilotId(Integer pilotId);

	public void updatePilot(Pilot pilot);

	public void deletePilot(Integer pilotId);

}
