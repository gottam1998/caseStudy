package com.main.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author gottammahesh.reddy It consists properties of Plane.
 */
@Entity
@Table(name = "plane")
public class Plane {
	@Id
	private Integer planeId;
	@NotEmpty
	@Size(min = 6, max = 15)
	private String planeName;
	@NotEmpty
	@Size(min = 6, max = 15)
	private String destination;
	@NotEmpty
	@Size(min = 6, max = 15)
	private String source;
	private Integer pilotId;
	private Integer hangarId;

	public Integer getPlaneId() {
		return planeId;
	}

	public void setPlaneId(Integer planeId) {
		this.planeId = planeId;
	}

	public String getPlaneName() {
		return planeName;
	}

	public void setPlaneName(String planeName) {
		this.planeName = planeName;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Integer getPilotId() {
		return pilotId;
	}

	public void setPilotId(Integer pilotId) {
		this.pilotId = pilotId;
	}

	public Integer getHangarId() {
		return hangarId;
	}

	public void setHangarId(Integer hangarId) {
		this.hangarId = hangarId;
	}

}
