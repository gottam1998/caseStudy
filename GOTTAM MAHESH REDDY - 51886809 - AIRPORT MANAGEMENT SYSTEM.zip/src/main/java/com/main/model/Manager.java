package com.main.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author gottammahesh.reddy It consists properties of Manager.
 */
@Entity
@Table(name = "manager")
public class Manager {
	@NotEmpty
	@Size(min = 6, max = 15)
	private String firstName;
	@NotEmpty
	@Size(min = 6, max = 15)
	private String lastName;
	@NotNull
	@Min(value = 18)
	@Max(value = 50)
	private Integer age;
	@NotEmpty
	private String gender;
	@NotNull
	private Long contactNumber;
	@Id
	private Integer managerId;
	@NotEmpty
	@Size(min = 8, max = 15)
	private String password;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Integer getManagerId() {
		return managerId;
	}

	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
