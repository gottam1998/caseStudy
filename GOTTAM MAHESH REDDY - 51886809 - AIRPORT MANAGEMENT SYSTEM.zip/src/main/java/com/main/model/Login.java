package com.main.model;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author gottammahesh.reddy It consists properties of Manager login.
 */
public class Login {
	@NotNull
	private Integer managerId;
	@NotEmpty
	private String password;

	public Integer getManagerId() {
		return managerId;
	}

	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
