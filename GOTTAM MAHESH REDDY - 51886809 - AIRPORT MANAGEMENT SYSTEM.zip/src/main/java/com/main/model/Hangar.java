package com.main.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author gottammahesh.reddy It consists properties of Hangar.
 */
@Entity
@Table(name = "Hangar")
public class Hangar {

	@Id
	private Integer hangarId;
	@NotEmpty
	@Size(min = 6, max = 15)
	private String hangarName;
	private String hangarStatus;
	private Integer planeId;

	public Integer getPlaneId() {
		return planeId;
	}

	public void setPlaneId(Integer planeId) {
		this.planeId = planeId;
	}

	public Integer getHangarId() {
		return hangarId;
	}

	public void setHangarId(Integer hangarId) {
		this.hangarId = hangarId;
	}

	public String getHangarName() {
		return hangarName;
	}

	public void setHangarName(String hangarName) {
		this.hangarName = hangarName;
	}

	public String getHangarStatus() {
		return hangarStatus;
	}

	public void setHangarStatus(String hangarStatus) {
		this.hangarStatus = hangarStatus;
	}

}
