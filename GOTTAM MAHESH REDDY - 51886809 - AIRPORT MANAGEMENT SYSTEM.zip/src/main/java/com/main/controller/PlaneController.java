package com.main.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.main.model.Hangar;
import com.main.model.Pilot;
import com.main.model.Plane;
import com.main.service.PlaneService;

/**
 * @author gottammahesh.reddy This is a Hangar controller It consists of methods
 *         regading hangar adding, editing and deleting
 */
@Controller
public class PlaneController {
	private static Logger log = Logger.getLogger(PlaneController.class);

	@Autowired
	private PlaneService planeService;

	@RequestMapping(value = "/redirectPlane", method = RequestMethod.GET)
	public String loadAddPlaneForm(ModelMap map) {
		log.info("Request inside loadAddPlaneForm method");
		Plane plane = new Plane();
		map.addAttribute("addPlaneForm", plane);
		return "AddPlane";
	}

	@RequestMapping(value = "/addPlane", method = RequestMethod.POST)
	public String savePlane(@Validated @ModelAttribute("addPlaneForm") Plane plane, BindingResult result,
			ModelMap map) {
		String viewPage;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage = "AddPlane";
		} else {
			log.info("Invoking save plane method");
			Random r = new Random();
			int planeId = r.nextInt(99999) + 10000;
			plane.setPlaneId(planeId);
			//plane.setPilotId(0);
			//plane.setHangarId(0);
			planeService.savePlane(plane);
			List<Plane> planeList = planeService.fetchPlane();
			map.addAttribute("planeList", planeList);
			viewPage = "ViewPlane";
		}
		return viewPage;
	}

	@RequestMapping(value = "/redirectViewPlane", method = RequestMethod.GET)
	public String loadViewPlanePage(ModelMap map) {
		log.info("Request inside loadViewPlanePage method");
		List<Plane> planeList = planeService.fetchPlane();
		map.addAttribute("planeList", planeList);
		return "ViewPlane";
	}

	@RequestMapping(value = "/fetchByPlaneId/{planeId}")
	public String fetchByPlaneId(@PathVariable("planeId") Integer planeId, ModelMap map) {
		log.info("Fetching plane by id");
		Plane plane = planeService.fetchByPlaneId(planeId);
		map.addAttribute("updateForm", plane);
		return "UpdatePlane";
	}

	@RequestMapping(value = "/updatePlane", method = RequestMethod.POST)
	public String updatePlane(@Validated @ModelAttribute("updateForm") Plane plane, BindingResult result,
			ModelMap map) {

		String editViewPage;
		if (result.hasErrors()) {
			log.info("Validation error occured");
			editViewPage = "UpdatePlane";
		} else {
			log.info("Invoking update data");
			planeService.updatePlane(plane);
			List<Plane> planeList = planeService.fetchPlane();
			map.addAttribute("planeList", planeList);
			editViewPage = "ViewPlane";
		}
		return editViewPage;
	}

	@RequestMapping(value = "/redirectViewPlanePilot", method = RequestMethod.GET)
	public String loadPlanePilotPage(ModelMap map) {
		log.info("Request inside loadPlanePilotPage method");
		List<Plane> planePilotList = planeService.fetchPlanePilot();
		map.addAttribute("planePilotList", planePilotList);
		return "ViewPlanePilot";
	}

	@RequestMapping(value = "/fetchByPlanePilotId/{planeId}")
	public String fetchByPlanePilotId(@PathVariable("planeId") Integer planeId, ModelMap map) {
		log.info("Fetching plane by id");
		Plane plane = planeService.fetchByPlanePilotId(planeId);
		map.addAttribute("updatePlanePilotForm", plane);
		return "UpdatePlanePilot";
	}

	@RequestMapping(value = "/updatePlanePilot", method = RequestMethod.POST)
	public String updatePlanePilot(@Validated @ModelAttribute("updatePlanePilotForm") Plane plane, BindingResult result,
			ModelMap map) {

		String editViewPage;
		if (result.hasErrors()) {
			log.info("Validation error occured");
			editViewPage = "UpdatePlanePilot";
		} else {
			log.info("Invoking update data");
			planeService.updatePlanePilot(plane);
			List<Plane> planePilotList = planeService.fetchPlanePilot();
			map.addAttribute("planePilotList", planePilotList);
			editViewPage = "ViewPlanePilot";
		}
		return editViewPage;
	}

	/*
	 * @RequestMapping(value = "/redirectViewPlaneHangar", method =
	 * RequestMethod.GET) public String loadPlaneHangarPage(ModelMap map) {
	 * log.info("Request inside loadPlaneHangarPage method"); List<Plane>
	 * planeHangarList = planeService.fetchPlaneHangar();
	 * map.addAttribute("planeHangarList", planeHangarList); return
	 * "ViewPlaneHangar"; }
	 * 
	 * @RequestMapping(value = "/fetchByPlaneHangarId/{planeId}") public String
	 * fetchByPlaneHangarId(@PathVariable("planeId") Integer planeId, ModelMap map)
	 * { log.info("Fetching plane by id"); Plane plane =
	 * planeService.fetchByPlaneHangarId(planeId);
	 * map.addAttribute("updatePlaneHangarForm", plane); return "UpdatePlaneHangar";
	 * }
	 * 
	 * @RequestMapping(value = "/updatePlaneHangar", method = RequestMethod.POST)
	 * public String
	 * updatePlaneHangar(@Validated @ModelAttribute("updatePlaneHangarForm") Plane
	 * plane, BindingResult result, ModelMap map) {
	 * 
	 * String editViewPage; if (result.hasErrors()) {
	 * log.info("Validation error occured"); editViewPage = "UpdatePlaneHangar"; }
	 * else { log.info("Invoking update data");
	 * planeService.updatePlaneHangar(plane); List<Plane> planeHangarList =
	 * planeService.fetchPlaneHangar(); map.addAttribute("planeHangarList",
	 * planeHangarList); editViewPage = "ViewPlaneHangar"; } return editViewPage; }
	 */
	@RequestMapping(value = "/deletePlane/{planeId}")
	public String deletePlane(@PathVariable("planeId") Integer planeId, ModelMap map) {
		log.info("Deleting plane based on plane id");
		planeService.deletePlane(planeId);
		// List<Employee> empList = employeeService.fetchEmployee();
		// map.addAttribute("employeeList", empList);
		return "redirect:/fetchPlane";
	}

	@RequestMapping(value = "/fetchPlane")
	public String fetchPlane(ModelMap map) {
		log.info("Fetching plane details");
		List<Plane> planeList = planeService.fetchPlane();
		map.addAttribute("planeList", planeList);
		return "ViewPlane";
	}

	@ModelAttribute("listOfPilotId")
	public List<Integer> listOfPilotId() {
		log.info("Fetching pilot id details from pilot table");
		List<Pilot> pilotList = planeService.fetchPilot();

		List<Integer> listOfPilotId = new ArrayList<>();

		for (Pilot pilot : pilotList) {
			listOfPilotId.add(pilot.getPilotId());
		}
		System.out.println("plane controller");
		System.out.println(listOfPilotId);
		return listOfPilotId;
	}

	@ModelAttribute("listOfPlaneId")
	public List<Integer> listOfPlaneId() {
		log.info("Fetching plane id details from plane table");
		List<Plane> planeList = planeService.fetchPlane();

		List<Integer> listOfPlaneId = new ArrayList<>();

		for (Plane plane : planeList) {
			listOfPlaneId.add(plane.getPlaneId());
		}
		System.out.println("plane controller");
		System.out.println(listOfPlaneId);
		return listOfPlaneId;
	}

}
