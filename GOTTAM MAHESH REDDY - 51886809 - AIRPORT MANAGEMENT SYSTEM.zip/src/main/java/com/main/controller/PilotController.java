package com.main.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.main.model.Pilot;
import com.main.model.Plane;
import com.main.service.PilotService;

/**
 * @author gottammahesh.reddy This is a Hangar controller It consists of methods
 *         regading pilot adding, editing and deleting
 */
@Controller
public class PilotController {
	private static Logger log = Logger.getLogger(PilotController.class);

	@Autowired
	private PilotService pilotService;

	@RequestMapping(value = "/redirectPilot", method = RequestMethod.GET)
	public String loadaddPilot(ModelMap map) {
		log.info("Request inside loadaddPilot method");
		Pilot pilot = new Pilot();
		map.addAttribute("addPilotForm", pilot);
		return "AddPilot";
	}

	@RequestMapping(value = "/addPilot", method = RequestMethod.POST)
	public String savePilot(@Validated @ModelAttribute("addPilotForm") Pilot pilot, BindingResult result,
			ModelMap map) {
		String viewPage;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage = "AddPilot";
		} else {
			log.info("Invoking save pilot method");
			Random r = new Random();
			int pilotId = r.nextInt(99999) + 10000;
			pilot.setPilotId(pilotId);
			pilotService.savePilot(pilot);
			List<Pilot> pilotList = pilotService.fetchPilot();
			map.addAttribute("pilotList", pilotList);
			viewPage = "ViewPilot";
		}
		return viewPage;
	}

	@RequestMapping(value = "/redirectViewPilot", method = RequestMethod.GET)
	public String loadViewPilotPage(ModelMap map) {
		log.info("Request inside loadViewPilotPage method");
		List<Pilot> pilotList = pilotService.fetchPilot();
		map.addAttribute("pilotList", pilotList);
		return "ViewPilot";
	}

	@RequestMapping(value = "/fetchByPilotId/{pilotId}")
	public String fetchByPilotId(@PathVariable("pilotId") Integer pilotId, ModelMap map) {
		log.info("Fetching pilot by id");
		Pilot pilot = pilotService.fetchByPilotId(pilotId);
		map.addAttribute("updateForm", pilot);
		return "UpdatePilot";
	}

	@RequestMapping(value = "/updatePilot", method = RequestMethod.POST)
	public String updateHangar(@Validated @ModelAttribute("updateForm") Pilot pilot, BindingResult result,
			ModelMap map) {

		String editViewPage;
		if (result.hasErrors()) {
			log.info("Validation error occured");
			editViewPage = "UpdatePilot";
		} else {
			log.info("Invoking update data");
			pilotService.updatePilot(pilot);
			List<Pilot> pilotList = pilotService.fetchPilot();
			map.addAttribute("pilotList", pilotList);
			editViewPage = "ViewPilot";
		}
		return editViewPage;
	}

	@RequestMapping(value = "/deletePilot/{pilotId}")
	public String deletePilot(@PathVariable("pilotId") Integer pilotId, ModelMap map) {
		log.info("Deleting plane based on pilot id");
		pilotService.deletePilot(pilotId);
		// List<Employee> empList = employeeService.fetchEmployee();
		// map.addAttribute("employeeList", empList);
		return "redirect:/fetchPilot";
	}

	@RequestMapping(value = "/fetchPilot")
	public String fetchPilot(ModelMap map) {
		List<Pilot> pilotList = pilotService.fetchPilot();
		map.addAttribute("pilotList", pilotList);
		return "ViewPilot";
	}

	/**
	 * @return
	 */
	@ModelAttribute("listOfPilotId")
	public List<Integer> listOfPilotId() {
		List<Pilot> pilotList = pilotService.fetchPilot();

		List<Integer> listOfPilotId = new ArrayList<>();

		for (Pilot pilot : pilotList) {
			listOfPilotId.add(pilot.getPilotId());
		}
		System.out.println("pilot controller");
		System.out.println(listOfPilotId);
		return listOfPilotId;
	}
}
