package com.main.controller;

import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.main.model.Login;
import com.main.model.Manager;
import com.main.service.ManagerService;

/**
 * @author gottammahesh.reddy This is a Hangar controller. It consists of methods
 *         regading Managar adding.
 */
@Controller
public class ManagerController {
	private static Logger log = Logger.getLogger(ManagerController.class);
	@Autowired
	private ManagerService managerService;

	@RequestMapping(value = "/redirectManager", method = RequestMethod.GET)
	public String loadManagerRegistrationForm(ModelMap map) {
		log.info("Request inside loadManagerRegistration method");
		Manager manager = new Manager();
		map.addAttribute("managerForm", manager);
		return "ManagerRegistrationForm";
	}

	@RequestMapping(value = "/saveManager", method = RequestMethod.POST)
	public String saveManager(@Validated @ModelAttribute("managerForm") Manager manager, BindingResult result,
			ModelMap map) {
		String viewPage;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage = "ManagerRegistrationForm";
		} else {
			log.info("Invoking save manager method");
			Random r = new Random();
			int managerId = r.nextInt(99999) + 10000;
			manager.setManagerId(managerId);
			managerService.saveManager(manager);
			// List<Manager> studList = managerService.fetchManager();
			// map.addAttribute("studentList", studList);
			Login login = new Login();
			map.addAttribute("managerLogin", login);
			viewPage = "ManagerLogin";
		}
		return viewPage;
	}

	@RequestMapping(value = "/redirectManagerLogin", method = RequestMethod.GET)
	public String loadManagerLoginForm(ModelMap map) {
		log.info("Request inside loadManagerLoginForm method");
		Login login = new Login();
		map.addAttribute("managerLogin", login);
		return "ManagerLogin";
	}

	@RequestMapping(value = "/fetchManager", method = RequestMethod.POST)
	public String fetchManager(@Validated @ModelAttribute("managerLogin") Login login, BindingResult result) {
		String authentication = managerService.fetchManager(login);
		String view = "";
		if (authentication == "valid") {
			view = "ManagerDashboard";
		} else {
			view = "ManagerLogin";
		}
		return view;

	}

}
