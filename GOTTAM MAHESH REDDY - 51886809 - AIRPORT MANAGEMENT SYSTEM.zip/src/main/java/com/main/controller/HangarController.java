package com.main.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.main.model.Hangar;
import com.main.model.Plane;
import com.main.service.HangarService;

/**
 * @author gottammahesh.reddy This is a Hangar controller. It consists of methods
 *         regarding hangar adding, editing and deleting
 */
@Controller
public class HangarController {

	private static Logger log = Logger.getLogger(HangarController.class);

	@Autowired
	private HangarService hangarService;

	@RequestMapping(value = "/redirectHangar", method = RequestMethod.GET)
	public String loadAddHangar(ModelMap map) {
		log.info("Request inside loadAddHangar method");
		Hangar hangar = new Hangar();
		map.addAttribute("hangarForm", hangar);
		return "AddHangar";
	}

	@RequestMapping(value = "/addHangar", method = RequestMethod.POST)
	public String saveHanger(@Validated @ModelAttribute("hangarForm") Hangar hangar, BindingResult result,
			ModelMap map) {
		String viewPage;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage = "AddHangar";
		} else {
			log.info("Invoking save hangar method");
			Random r = new Random();
			int hangarId = r.nextInt(99999) + 10000;
			hangar.setHangarId(hangarId);
			hangar.setHangarStatus("Available");
			hangarService.saveHangar(hangar);
			List<Hangar> hangList = hangarService.fetchHangar();
			map.addAttribute("hangarList", hangList);
			viewPage = "ViewHangar";
		}
		return viewPage;
	}

	@RequestMapping(value = "/redirectViewHangar", method = RequestMethod.GET)
	public String loadViewHangarPage(ModelMap map) {
		log.info("Request inside loadViewHangarPage method");
		List<Hangar> hangList = hangarService.fetchHangar();
		map.addAttribute("hangarList", hangList);
		return "ViewHangar";
	}

	@RequestMapping(value = "/fetchByHangarId/{hangarId}")
	public String fetchHangarById(@PathVariable("hangarId") Integer hangarId, ModelMap map) {
		log.info("Fetching hangar by id");
		Hangar hangar = hangarService.fetchHangarById(hangarId);
		map.addAttribute("updateForm", hangar);
		return "UpdateHangar";
	}

	@RequestMapping(value = "/updateHangar", method = RequestMethod.POST)
	public String updateHangar(@Validated @ModelAttribute("updateForm") Hangar hangar, BindingResult result,
			ModelMap map) {

		String editViewPage;
		if (result.hasErrors()) {
			log.info("Validation error occured");
			editViewPage = "UpdateHangar";
		} else {
			log.info("Invoking update data");
			hangarService.updateHangar(hangar);
			List<Hangar> hangerList = hangarService.fetchHangar();
			map.addAttribute("hangarList", hangerList);
			editViewPage = "ViewHangar";
		}
		return editViewPage;
	}

	@RequestMapping(value = "/deleteHangar/{hangarId}")
	public String deleteHangar(@PathVariable("hangarId") Integer hangerId, ModelMap map) {
		log.info("Deleting hangar based on hangar id");
		hangarService.deleteHangar(hangerId);
		// List<Employee> empList = employeeService.fetchEmployee();
		// map.addAttribute("employeeList", empList);
		return "redirect:/fetchHangar";
	}

	@RequestMapping(value = "/fetchHangar")
	public String fetchHangar(ModelMap map) {
		log.info("Fetch hangar");
		List<Hangar> hangarList = hangarService.fetchHangar();
		map.addAttribute("hangarList", hangarList);
		return "ViewHangar";
	}

	@RequestMapping(value = "/redirectViewPlaneHangar", method = RequestMethod.GET)
	public String loadPlaneHangarPage(ModelMap map) {
		log.info("Request inside loadPlaneHangarPage method");
		List<Hangar> planeHangarList = hangarService.fetchPlaneHangar();
		map.addAttribute("planeHangarList", planeHangarList);
		return "ViewPlaneHangar";
	}

	@RequestMapping(value = "/fetchByPlaneHangarId/{hangarId}")
	public String fetchByPlaneHangarId(@PathVariable("hangarId") Integer hangarId, ModelMap map) {
		log.info("Fetching hangar by id");
		Hangar hangar = hangarService.fetchByPlaneHangarId(hangarId);
		map.addAttribute("updatePlaneHangarForm", hangar);
		return "UpdatePlaneHangar";
	}

	@RequestMapping(value = "/updatePlaneHangar", method = RequestMethod.POST)
	public String updatePlaneHangar(@Validated @ModelAttribute("updatePlaneHangarForm") Hangar hangar,
			BindingResult result, ModelMap map) {

		String editViewPage;
		if (result.hasErrors()) {
			log.info("Validation error occured");
			editViewPage = "UpdatePlaneHangar";
		} else {
			log.info("Invoking update data");
			hangar.setHangarStatus("Alloted");
			hangarService.updatePlaneHangar(hangar);
			List<Hangar> planeHangarList = hangarService.fetchPlaneHangar();

			map.addAttribute("planeHangarList", planeHangarList);
			editViewPage = "ViewPlaneHangar";
		}
		return editViewPage;
	}

	@ModelAttribute("listOfPlaneId")
	public List<Integer> listOfPlaneId() {
		log.info("Getting planeId from plane table ");
		List<Plane> planeList = hangarService.fetchPlane();

		List<Integer> listOfPlaneId = new ArrayList<>();

		for (Plane plane : planeList) {
			listOfPlaneId.add(plane.getPlaneId());
		}
		System.out.println("hangar controller");
		System.out.println(listOfPlaneId);
		return listOfPlaneId;
	}

}
