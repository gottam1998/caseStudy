package com.main.controller;

import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.main.model.Admin;
import com.main.model.AdminLogin;
import com.main.model.Login;
import com.main.service.AdminService;

/**
 * @author gottammahesh.reddy This is an Admin Controller which consists of
 *         Admin authentication
 */
@Controller
public class AdminController {

	private static Logger log = Logger.getLogger(AdminController.class);

	@Autowired
	private AdminService adminService;

	@RequestMapping(value = "/redirectAdmin", method = RequestMethod.GET)
	public String loadAdminRegistrationForm(ModelMap map) {
		log.info("Request inside loadAdminRegistrationForm method");
		Admin admin = new Admin();
		map.addAttribute("adminForm", admin);
		return "AdminRegistrationForm";
	}

	@RequestMapping(value = "/saveAdmin", method = RequestMethod.POST)
	public String saveEmployee(@Validated @ModelAttribute("adminForm") Admin admin, BindingResult result,
			ModelMap map) {
		String viewPage;
		if (result.hasErrors()) {
			log.info("Validation errors occured");
			viewPage = "AdminRegistrationForm";
		} else {
			log.info("Invoking save admin method");
			Random r = new Random();
			int adminId = r.nextInt(99999) + 10000;
			admin.setAdminId(adminId);
			adminService.saveAdmin(admin);
			AdminLogin adminlogin = new AdminLogin();
			map.addAttribute("adminLogin", adminlogin);
			viewPage = "AdminSuccess";
		}
		return viewPage;
	}

	@RequestMapping(value = "/redirectAdminLogin", method = RequestMethod.GET)
	public String loadAdminLoginForm(ModelMap map) {
		log.info("Request inside loadAdminLoginForm method");
		AdminLogin adminlogin = new AdminLogin();
		map.addAttribute("adminLogin", adminlogin);
		return "AdminLoginPage";
	}

	@RequestMapping(value = "/fetchAdmin", method = RequestMethod.POST)
	public String fetchManager(@Validated @ModelAttribute("adminLogin") AdminLogin adminLogin, BindingResult result) {
		log.info("Request inside fetchManager method");
		String authentication = adminService.fetchAdmin(adminLogin);
		String view = "";
		if (authentication == "valid") {
			view = "AdminDashboard";
		} else {
			view = "AdminLoginPage";
		}
		return view;

	}

}
